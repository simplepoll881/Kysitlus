const express = require('express');
const app = express();
const polls = {};
app.use(express.json());
app.use(express.static('public'));
app.post('/create', (req,res)=>{
  const id = Math.random().toString(36).substring(2,8);
  polls[id]={question:req.body.question, options:req.body.options, votes:Array(req.body.options.length).fill(0)};
  res.json({pollId:id});
});
app.post('/vote/:id',(req,res)=>{
  const poll=polls[req.params.id]; if(!poll) return res.status(404).end();
  poll.votes[req.body.index]++;
  res.json({ok:true});
});
app.get('/poll/:id',(req,res)=>res.json(polls[req.params.id]||null));
const PORT=process.env.PORT||3000;
app.listen(PORT,()=>console.log('SimplePoll running on '+PORT));